from .checkCertValidity import checkCertValidity
from .createSelfSignedRootCert import is_valid_email, createSelfSignedRootCert
from .createSignedCert import is_valid_email, createSignedCert
from .getCertInfo import get_serial_number
from .getCertInfo import get_owner
from .getCertInfo import get_validity_end
from .getCertInfo import get_validity_start
from .exceptions import (
    CertificateError,
    CertificateFileNotFoundError,
    CertificateFileEmptyError,
    CertificateLoadError,
    CertificateSaveError,
    CertificateSigningError,
    InvalidCertificateError,
    CertificateDateError,
    PrivateKeyFileNotFoundError,
    PublicKeyFileNotFoundError,
    PrivateKeyLoadError,
    PublicKeyLoadError,
    InvalidKeySizeError,
    KeyPairGenerationError,
    KeySaveError,
    DirectoryCreationError,
    UnsupportedAlgorithmError,
)
from .generateKeyPair import generateKeyPair, generateKeyPairBytes
from .fingerprint import getCertificateFingerprint
from .fingerprint import getPublicKeyFingerprint
from .createSignedInterCert import createSignedInterCert
from .generateCsr import generateCsr
from .parseCsr import parseCsr

__version__ = "0.0.12"
VERSION = __version__.split(".")

# ---------------------------------------------------------------------------
# Constantes publiques — algorithmes et courbes supportés
# Importables directement : from cheetahpki import SUPPORTED_ALGORITHMS
# ---------------------------------------------------------------------------
SUPPORTED_ALGORITHMS = ("RSA", "EC", "Ed25519", "Ed448")
SUPPORTED_CURVES = ("P-256", "P-384", "P-521")   # uniquement pour algorithm="EC"

__all__ = (
    # Fonctions de génération de clés
    'generateKeyPair',         # Écrit sur le filesystem (FileField / stockage local)
    'generateKeyPairBytes',    # Retourne des bytes PEM en mémoire (Vault / stockage sécurisé)
    'SUPPORTED_ALGORITHMS',
    'SUPPORTED_CURVES',
    # Fonctions de création de certificats
    'createSelfSignedRootCert',
    'createSignedCert',
    'createSignedInterCert',
    # Fonctions CSR
    'generateCsr',
    'parseCsr',
    # Fonctions d'info et de validité
    'checkCertValidity',
    'is_valid_email',
    'get_owner',
    'get_serial_number',
    'get_validity_start',
    'get_validity_end',
    'getCertificateFingerprint',
    'getPublicKeyFingerprint',
    # Exceptions
    'CertificateError',
    'CertificateFileNotFoundError',
    'CertificateFileEmptyError',
    'CertificateLoadError',
    'CertificateSaveError',
    'CertificateSigningError',
    'InvalidCertificateError',
    'CertificateDateError',
    'PrivateKeyFileNotFoundError',
    'PublicKeyFileNotFoundError',
    'PrivateKeyLoadError',
    'PublicKeyLoadError',
    'InvalidKeySizeError',
    'KeyPairGenerationError',
    'KeySaveError',
    'DirectoryCreationError',
    'UnsupportedAlgorithmError',
)